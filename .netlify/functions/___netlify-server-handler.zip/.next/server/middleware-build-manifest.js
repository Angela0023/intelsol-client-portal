globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/G3Z-sZpfB7bh4hWmD2G0e/_buildManifest.js",
    "static/G3Z-sZpfB7bh4hWmD2G0e/_ssgManifest.js",
    "static/G3Z-sZpfB7bh4hWmD2G0e/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/00gq-v0e07i1q.js",
    "static/chunks/02i7dfk78~t~2.js",
    "static/chunks/01qvgvnw-eatl.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/turbopack-180ow4d1_gkg8.js"
  ]
};
